var _vga_logic_8c =
[
    [ "API_check_outside_screen", "group___a_p_i-_logic.html#gad6ab7443274ea22feb17f32c26d09088", null ],
    [ "API_clearscreen", "group___a_p_i-_logic.html#gac5d34bcb0d84db1190d4b876a3f65944", null ],
    [ "API_draw_bitmap", "group___a_p_i-_logic.html#ga6eeb30f90b8b94e5bdceb4847f5f77e1", null ],
    [ "API_draw_character", "group___a_p_i-_logic.html#ga786fa1edc12315b3ccb411cae9dc3ae5", null ],
    [ "API_draw_circle", "group___a_p_i-_logic.html#gaafb5c2810f8084bed6b20e4c398f0fc8", null ],
    [ "API_draw_figure", "group___a_p_i-_logic.html#ga99e8e55a36e036be0423fdb06a02820b", null ],
    [ "API_draw_line", "group___a_p_i-_logic.html#ga3fd40a7f05424ffe7b0ef94c8c7f7315", null ],
    [ "API_draw_rectangle", "group___a_p_i-_logic.html#ga62957deeb57f3a25c8d0727c8c9a8b40", null ],
    [ "API_draw_simple_line", "group___a_p_i-_logic.html#ga3ceed65813f07e51e8bee8fdc82fa451", null ],
    [ "API_draw_text", "group___a_p_i-_logic.html#gacd665154361594d5ddb6363d6191d885", null ],
    [ "API_get_font_value", "group___a_p_i-_logic.html#gaf8f77293004e98b82a015ab7e836645a", null ],
    [ "API_init", "group___a_p_i-_logic.html#gad1b28429e9f113344ce334f0626b6ed6", null ],
    [ "API_word_pixel_size", "group___a_p_i-_logic.html#gafa07605ab7880a512a893aad040bd6b9", null ]
];