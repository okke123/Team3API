var group___a_p_i =
[
    [ "API Fonts", "group___a_p_i-_f_o_n_t_s.html", "group___a_p_i-_f_o_n_t_s" ],
    [ "API IO Layer", "group___a_p_i-_i_o.html", "group___a_p_i-_i_o" ],
    [ "API Logic Layer", "group___a_p_i-_logic.html", "group___a_p_i-_logic" ],
    [ "API Defines", "group___a_p_i-_defines.html", null ]
];