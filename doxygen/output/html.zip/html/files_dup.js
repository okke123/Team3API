var files_dup =
[
    [ "API", "dir_19ea4dbfe8f0e4681f60b9b97f7b5d11.html", "dir_19ea4dbfe8f0e4681f60b9b97f7b5d11" ],
    [ "Application", "dir_eb1463819d84903762eb6f59cc0c4383.html", "dir_eb1463819d84903762eb6f59cc0c4383" ]
];