var struct_v_g_a__t =
[
    [ "dma2_cr_reg", "struct_v_g_a__t.html#a1fc3c1405cc22f5d4fc21eb58c47c06a", null ],
    [ "hsync_cnt", "struct_v_g_a__t.html#a649bc185f93377aec7fa1c136dd2add0", null ],
    [ "start_adr", "struct_v_g_a__t.html#a7f47a855ae47844b419d75797f00fbbb", null ]
];