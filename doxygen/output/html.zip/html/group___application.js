var group___application =
[
    [ "App Front Layer", "group___a_p_p-_f_r_o_n_t.html", "group___a_p_p-_f_r_o_n_t" ],
    [ "App Logic Layer", "group___a_p_p-_l_o_g_i_c.html", "group___a_p_p-_l_o_g_i_c" ],
    [ "App Defines", "group___a_p_p-_d_e_f_i_n_e_s.html", null ],
    [ "App Uart (IO) Layer", "group___a_p_p-_u_a_r_t.html", "group___a_p_p-_u_a_r_t" ]
];