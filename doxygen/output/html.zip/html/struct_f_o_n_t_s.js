var struct_f_o_n_t_s =
[
    [ "bitmap", "struct_f_o_n_t_s.html#a3824b60bac1b94cefcb808c3c3afd917", null ],
    [ "bitmap_info", "struct_f_o_n_t_s.html#a341d15854bd743d4434242e7da66688a", null ]
];