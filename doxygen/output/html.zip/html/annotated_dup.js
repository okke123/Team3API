var annotated_dup =
[
    [ "FONT_INFO", "struct_f_o_n_t___i_n_f_o.html", "struct_f_o_n_t___i_n_f_o" ],
    [ "FONTS", "struct_f_o_n_t_s.html", "struct_f_o_n_t_s" ],
    [ "TypeDefBitmap", "struct_type_def_bitmap.html", "struct_type_def_bitmap" ],
    [ "VGA_t", "struct_v_g_a__t.html", "struct_v_g_a__t" ]
];