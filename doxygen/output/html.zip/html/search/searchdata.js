var indexSectionsWithContent =
{
  0: "abcdfgmstv",
  1: "ftv",
  2: "afv",
  3: "adtv",
  4: "abcgmsv",
  5: "a",
  6: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Modules",
  6: "Pages"
};

