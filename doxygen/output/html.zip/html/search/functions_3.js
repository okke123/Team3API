var searchData=
[
  ['vgaioclearscreen',['VgaIOClearScreen',['../group___a_p_i-_i_o.html#ga24755a2906dacb89a90d14df827fc8ce',1,'VgaIOClearScreen(int color):&#160;VgaIO.c'],['../group___a_p_i-_i_o.html#ga24755a2906dacb89a90d14df827fc8ce',1,'VgaIOClearScreen(int color):&#160;VgaIO.c']]],
  ['vgaioinit',['VgaIOInit',['../group___a_p_i-_i_o.html#gae9bf0f9927be44304c9288f52044b880',1,'VgaIOInit(void):&#160;VgaIO.c'],['../group___a_p_i-_i_o.html#gae9bf0f9927be44304c9288f52044b880',1,'VgaIOInit(void):&#160;VgaIO.c']]],
  ['vgaioinitdma',['VgaIOInitDMA',['../group___a_p_i-_i_o.html#gae760d46caa6b00df72640a9f1a6fb91b',1,'VgaIO.c']]],
  ['vgaioinitgpio',['VgaIOInitGPIO',['../group___a_p_i-_i_o.html#ga75a185040feab66c7d83d3fac2313f30',1,'VgaIO.c']]],
  ['vgaioinitint',['VgaIOInitINT',['../group___a_p_i-_i_o.html#gaf08c4306e442334498444346824e0de3',1,'VgaIO.c']]],
  ['vgaioinittim',['VgaIOInitTIM',['../group___a_p_i-_i_o.html#ga2883d60c602419b22d8dd32a2ff04941',1,'VgaIO.c']]],
  ['vgaiosetbitmap',['VgaIOSetBitmap',['../group___a_p_i-_i_o.html#gafc57beb34a803fffe153f385e9db22a9',1,'VgaIOSetBitmap(int xp, int yp, TypeDefBitmap *bitmap):&#160;VgaIO.c'],['../group___a_p_i-_i_o.html#gafc57beb34a803fffe153f385e9db22a9',1,'VgaIOSetBitmap(int xp, int yp, TypeDefBitmap *bitmap):&#160;VgaIO.c']]],
  ['vgaiosetline',['VgaIOSetLine',['../group___a_p_i-_i_o.html#ga3e751cde6531afa4cb23dcd91b2af549',1,'VgaIOSetLine(int xp, int yp, int length, int color):&#160;VgaIO.c'],['../group___a_p_i-_i_o.html#ga3e751cde6531afa4cb23dcd91b2af549',1,'VgaIOSetLine(int xp1, int xp2, int yp, int color):&#160;VgaIO.c']]],
  ['vgaiosetpixel',['VgaIOSetPixel',['../group___a_p_i-_i_o.html#ga42927d901824147fd8e850367a57fa3e',1,'VgaIOSetPixel(int xp, int yp, int color):&#160;VgaIO.c'],['../group___a_p_i-_i_o.html#ga42927d901824147fd8e850367a57fa3e',1,'VgaIOSetPixel(int xp, int yp, int color):&#160;VgaIO.c']]]
];
