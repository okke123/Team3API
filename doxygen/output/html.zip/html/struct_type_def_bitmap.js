var struct_type_def_bitmap =
[
    [ "height", "struct_type_def_bitmap.html#ad13e9131f5062934438fa82334e4b2ee", null ],
    [ "img", "struct_type_def_bitmap.html#af369422cd7ac3895786c48ffcbbd5d7a", null ],
    [ "size", "struct_type_def_bitmap.html#aab938108caad0d0e47d6885b5ba2d23a", null ],
    [ "width", "struct_type_def_bitmap.html#a837aabdd54757cb86d0f66387511753f", null ]
];