var struct_f_o_n_t___i_n_f_o =
[
    [ "font_adr", "struct_f_o_n_t___i_n_f_o.html#a7c6860ceed220ed5dc1cea880e6cae35", null ],
    [ "width", "struct_f_o_n_t___i_n_f_o.html#a2474a5474cbff19523a51eb1de01cda4", null ]
];